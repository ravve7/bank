# TODO (11/04/2017)
- Complete the customer creation by assigning some account to him
- find a way to display the content of the customer instance after it has been initialized
- What if we want to store the customer content into a file?

- Store content to file: implement Serializable (https://www.mkyong.com/java/how-to-write-an-object-to-file-in-java/)