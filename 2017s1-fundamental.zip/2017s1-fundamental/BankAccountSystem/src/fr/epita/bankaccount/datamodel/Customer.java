/**
 *
 */
package fr.epita.bankaccount.datamodel;

import java.io.Serializable;
import java.util.List;

/**
 * @author tbrou
 *
 */
public class Customer implements Serializable {

    public static final long serialVersionUID = 1;

    private String name;
    private String address;

    List<Account> accounts;

    /**
     * @param name
     * @param address
     */
    public Customer(String name, String address) {
        this.name = name;
        this.address = address;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the accounts
     */
    public List<Account> getAccounts() {
        return accounts;
    }

    /**
     * @param accounts the accounts to set
     */
    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

    @Override
    public String toString() {
        return "Customer name: " + this.name + "; customer address: " + this.address;
    }

}
