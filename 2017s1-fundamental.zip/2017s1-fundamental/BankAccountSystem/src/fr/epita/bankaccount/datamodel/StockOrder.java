/**
 * 
 */
package fr.epita.bankaccount.datamodel;

/**
 * @author tbrou
 *
 */
public class StockOrder {

	int quantity;
	double commission;
	
}
