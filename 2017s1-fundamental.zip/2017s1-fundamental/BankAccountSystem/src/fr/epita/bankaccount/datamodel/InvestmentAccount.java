/**
 *
 */
package fr.epita.bankaccount.datamodel;

/**
 * @author tbrou
 *
 */
public class InvestmentAccount extends Account {

}
