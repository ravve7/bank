/**
 *
 */
package fr.epita.bankaccount.datamodel;

/**
 * @author tbrou
 *
 */
public class SavingsAccount extends Account {

    double interestRate;
}
