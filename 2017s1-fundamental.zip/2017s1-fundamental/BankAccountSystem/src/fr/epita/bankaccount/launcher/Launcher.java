/**
 *
 */
package fr.epita.bankaccount.launcher;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fr.epita.bankaccount.datamodel.*;

/**
 * @author tbrou
 *
 */
public class Launcher {

    /**
     * @param args
     */
    public static void main(String[] args) {
        List<Customer> customers = new ArrayList<Customer>();
        System.out.println("Hello! Welcome to the bank account system");

        System.out.println("What would you like to do ?");
        System.out.println("1. Create a customer");
        System.out.println("2. Create an account");
        System.out.println("3. Save Customer into a file");
        System.out.println("your choice : ");

        Scanner scanner = new Scanner(System.in);

        String line = scanner.nextLine();
        System.out.println("you have selected :" + line);

        // analyse the answer
        //		if ("1".equals(line)) {
        //			System.out.println("you have selected customer creation");
        //		} else if ("2".equals(line)) {
        //
        //		} else if ("3".equals(line)) {
        //
        //		}
        // alternate way to do the same test :
        switch (line) {
        case "1":
            System.out.println("you have selected customer creation");
            System.out.println("Input customer name :");
            String customerName = scanner.nextLine();
            System.out.println("Input customer address :");
            String customerAddress = scanner.nextLine();

            Customer customer = new Customer(customerName, customerAddress);
            customers.add(customer);

            System.out.println(customer);

            break;
        case "2":
            System.out.println("you have selected account creation");
            System.out.println("who is the owner of account:");
            for (int i = 0; i < customers.size(); i++) {
                System.out.println((i + 1) + ". " + customers.get(i).getName());
            }
            int customerId = scanner.nextInt() - 1;
            Customer selectedCustomer = customers.get(customerId);
            if (selectedCustomer.getAccounts() == null) {
                selectedCustomer.setAccounts(new ArrayList<Account>());
            }

            System.out.println("Choose account type: ");
            System.out.println("1. Saving Account");
            System.out.println("2. Investment Account");
            int accType = scanner.nextInt();
            Account account;
            if (accType == 1) {
                account = new SavingsAccount();
            } else if (accType == 2) {
                account = new InvestmentAccount();
            } else {
                account = null;
            }

            if (account != null) {
                selectedCustomer.getAccounts().add(account);
            }

            break;
        case "3":
            break;
        default:

        }
    }

    public void saveCustomerToFile(Customer customer, String path) {
        ObjectOutputStream oOut = null;
        FileOutputStream fOut = null;

        try {
            fOut = new FileOutputStream(path);
            oOut = new ObjectOutputStream(fOut);
            oOut.writeObject(customer);
        } catch (Exception ex) {
            // exception
        } finally {
            if (fOut != null) {
                try {
                    fOut.close();
                } catch (Exception ex) {
                    // exception
                }
            }

            if (oOut != null) {
                try {
                    oOut.close();
                } catch (Exception ex) {
                    // exception
                }
            }
        }
    }

}
